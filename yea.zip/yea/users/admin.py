from django.contrib import admin
from django.db.models import fields
from django.utils.translation import gettext_lazy as _
from .models import *
from django.contrib.auth.admin import UserAdmin
from django.forms import TextInput, Textarea
from import_export.admin import ImportExportModelAdmin

# Register your models here.
class CustomUserAdmin(UserAdmin):
    model = CustomUser
    search_fields = ('email', 'first_name', 'last_name',)
    list_filter = ('email', 'first_name', 'last_name', 'is_active',)
    ordering = ('-date_joined',)
    list_display = ('get_full_name', 'email', 'is_active', 'is_contestant')
    fieldsets = (
        (None, {'fields': ('email', 'password',)}),
        (_('Personal info'), {'fields': ('first_name', 'last_name', 'phone', 'avatar', "country")}),
        (_('Permissions'), {
            'fields': ('tos','is_active',  'is_superuser', 'is_admin', 'is_contestant', 'is_subscriber', 'is_editor', 'is_paid', 'is_staff', 'groups', 'user_permissions', ),
        }),
        (_('Important dates'), {'fields': ('last_login',)}),
    )

    # add_fieldsets = (
    #     (None, {
    #         'classes': ('wide',),
    #         'fields': ('email', 'first_name', 'last_name', 'password1', 'password2', 'is_active', 'is_staff',)}
    #      ),
    # )

admin.site.register(CustomUser, CustomUserAdmin)

@admin.register(Country)
class CountryAdmin(ImportExportModelAdmin):
    list_display = ('name',)


