import uuid
import requests
import json
import string
import threading
import random
import datetime
from PIL import Image
from io import BytesIO
from datetime import date

from django.conf import settings
from django.core.files import File
from django.core.mail import EmailMessage
from django.template.loader import render_to_string


class EmailThread(threading.Thread):

    def __init__(self, email):
        self.email = email
        threading.Thread.__init__(self)

    def run(self):
        self.email.fail_silently = False
        self.email.send()


def generate_order_id():
    date_str = date.today().strftime('%Y%m%d')[2:] + str(datetime.datetime.now().second)
    rand_str = "".join([random.choice(string.digits) for count in range(3)])
    return date_str + rand_str


# def send_out_invitation(subject, receiver, data):
#     sender_email_template = render_to_string(
#         "ticketing/email_template/ticket_email.html", {'ticket_image': data['ticket_image']})
#     mail = EmailMessage(subject, sender_email_template, 'info@eventstracer.com',
#                         receiver)
#     mail.attach_file(data['invitation']); mail.content_subtype = "html"
#     mail.send()


# def send_out_invitation(subject, receiver, data):
#     event = data['event']
#     invitation = data['invitation']
#     sender_email_template = render_to_string(
#         "ticketing/email_template/ticket_email.html", {'event': event})
#     mail = EmailMessage(subject, sender_email_template,
#                         'info@eventstracer.com', receiver)
#     mail.attach_file(invitation.ticket.path)
#     mail.content_subtype = "html"
#     mail.send()

class Flutterwave(object):
    def __init__(self):
        self.url = 'https://api.flutterwave.com/v3/'
        self.secret_key = settings.FLUTTERWAVE_SECRET_KEY
        self.headers = {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer {0}'.format(self.secret_key)
        }

    def get(self, path='', **params):
        return requests.get('{0}{1}'.format(self.url, path), params=params, headers=self.headers)

    def post(self, path='', params=''):
        return requests.post('{0}{1}'.format(self.url, path), data=params, headers=self.headers)

    def put(self, path='', params=''):
        return requests.put('{0}{1}'.format(self.url, path), data=params, headers=self.headers)
    


def generate_random_id():
    return str(uuid.uuid4())[:8].replace('-', '').lower()


def id_generator(size=15, chars=string.digits):
    return ''.join(random.choice(chars) for _ in range(size))

