from django.core.management.base import BaseCommand
from vote.models import Contestant

class Command(BaseCommand):
    help = 'Checks dropable contestants from the contestant.'
    
    def handle(self, *args, **options):
        non_dropped_contestants = Contestant.objects.filter(dropped=False)
        for ndc in non_dropped_contestants:
            if not ndc.has_achieved_weekly_vote_target():
                ndc.dropped = True
                ndc.save()
                
                self.stdout.write(self.style.SUCCESS('Dropped contestant "%s"' % ndc.id))