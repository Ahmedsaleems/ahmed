from django.shortcuts import render

from blog.models import Blog
from .models import Management, Nominees

def home(request):
    blogs = Blog.objects.filter(publish=True)
    nominees = Nominees.objects.all()
    management = Management.objects.all()[:3]

    context = { 
        'management': management, 
        'blogs':blogs,
        'nominees': nominees
     }

    return render(request, 'frontend/home.html', context)




def entyCategoryView(request):
    return render(request, 'frontend/entry.html')


def TosView(request):
    return render(request, 'frontend/tos.html')


def HowToView(request):
    return render(request, 'frontend/howto.html')


def AboutView(request):
    return render(request, 'frontend/about.html')


def ContactView(request):
    return render(request, 'frontend/contact.html')



