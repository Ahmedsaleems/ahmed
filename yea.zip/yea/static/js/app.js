// Js for Mobile Menu
function myFunction() {
    var element = document.getElementById("navbar-toggler");
    element.classList.toggle("active");
  }


// Js for carourel
$('.owl-carousel').owlCarousel({
  loop:true,
  nav: true,
  dots:true,
  autoplay:true,
  autoplayTimeout:1000,

  responsive:{
      0:{
          items:3
      },
      576:{
          items:3
      },
      768:{
          items:4
      },
      1000:{
          items:5
      }
  }
})

// JS for Counter

$('.counter').counterUp({
    delay: 10,
    time: 1000
});


// JS for Vertical Slider

var slides = document.querySelectorAll('.slide');
var button = document.querySelectorAll('.slide_btn');
var circle = document.querySelectorAll('.circle_btn');
let currentSlide = 1;

var manualNav = function (manual){
    slides.forEach((slide) => {
        slide.classList.remove('slide_active');
        button.forEach((btn) =>{
            btn.classList.remove('btn_active');
            circle.forEach((circle) =>{
                circle.classList.remove('crl_active');
            })
        })
    })
    slides[manual].classList.add('slide_active');
    button[manual].classList.add('btn_active');
    circle[manual].classList.add('crl_active');

}

button.forEach((btn, i)=>{
    btn.addEventListener("click", ()=>{
        manualNav(i);
        currentSlide = i; 
    });
});

var repeat = function (activeClass){
    let slide_active = document.getElementsByClassName("slide_active");
    let btn_active = document.getElementsByClassName("btn_active");
    let crl_active = document.getElementsByClassName("crl_active");
    let i = 1;

    var repeater = () => {
        setTimeout(function(){

            [...slide_active].forEach((activeSlide) =>{
                activeSlide.classList.remove("slide_active");
                [...btn_active].forEach((activeSlide) =>{
                activeSlide.classList.remove("btn_active");
                    [...crl_active].forEach((activeSlide) =>{
                    activeSlide.classList.remove("crl_active");
                    })
                })
            })
            slides[i].classList.add('slide_active');
            button[i].classList.add('btn_active');
            circle[i].classList.add('crl_active');
            i++

            if (slides.length == i){
                i = 0;
            }
            if (i>=0 == slides.length){
                return;
            }
            repeater();

        },3000)
    }
    repeater();
}
repeat();