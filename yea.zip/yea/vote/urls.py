from django.urls import path
from .views import *

app_name = 'vote'

urlpatterns = [
    path('contest/', contestView, name='contest'),
    path('vote-now/', voteNow, name='vote_now'),
    path('vote-post/', votePost, name='vote_post'),
    path('recharge/', recharge, name='recharge'),
    path('verify-payment/', verify_payment, name='verify'),
    path('share/<slug:slug>/', share_page, name="share"),

]