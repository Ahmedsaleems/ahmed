from django.contrib import admin
from .models import*
from import_export.admin import ImportExportModelAdmin





class ContestantAdmin(admin.ModelAdmin):
    list_display = ('user', 'createdAt', 'vote_count', 'dob', 'address', 'business_venture',
     'contesting', 
    )

admin.site.register(Contestant, ContestantAdmin)


admin.site.register(BusinessVenture)

class SlotsAdmin(admin.ModelAdmin):
    list_display = ('user', 'vote_slots', 'createdAt')

admin.site.register(Slots, SlotsAdmin)


class ContestControlAdmin(admin.ModelAdmin):
    list_display = ('title', 'start_date', 'end_date')

admin.site.register(ContestSettings, ContestControlAdmin)


class WinnersAdmin(admin.ModelAdmin):
    list_display = ('user', 'year', 'amount_won')

admin.site.register(Winners, WinnersAdmin)


class AwardTypeAdmin(admin.ModelAdmin):
    list_display = ('award_title', 'target_votes', 'price', 'start_date', 'end_date')

admin.site.register(AwardType, AwardTypeAdmin)



class LevelsControlAdmin(admin.ModelAdmin):
    list_display = ('user', 'week_table')

admin.site.register(LevelsControl, LevelsControlAdmin)



@admin.register(WeekTable)
class WeekTableAdmin(ImportExportModelAdmin):
    list_display = ['title', 'week_number', 'target', 'start_date', 'end_date', 'award_type']
    pass


@admin.register(Category)
class CategoryAdmin(ImportExportModelAdmin):
    list_display = ('name',)


