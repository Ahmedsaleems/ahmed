from django.urls import path
from .views import *

app_name = 'subscription'

urlpatterns = [
    path('verify-payment/', verify_payment, name='verify'),
    path('subscribe/', subscribe, name='subscribe'),

]