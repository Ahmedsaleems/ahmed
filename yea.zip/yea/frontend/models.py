from django.db import models
from solo.models import SingletonModel
from django_summernote.fields import  SummernoteTextField


class FrontPage(SingletonModel):
    title = models.CharField(max_length=255, blank=True, null=True)
    body = models.TextField(blank=True, null=True)
    ceo_image = models.ImageField(blank=True, null=True, upload_to="images")
    ceo_name = models.CharField(max_length=255, blank=True, null=True)
    ceo_title = models.CharField(max_length=255, blank=True, null=True)
    banner_text = models.TextField(blank=True, null=True)
    banner_title = models.CharField(max_length=255, blank=True, null=True)
    banner_image = models.ImageField(blank=True, null=True, upload_to="images")
    blog_title = models.CharField(max_length=255, blank=True, null=True)
    blog_subtitle = models.CharField(max_length=255, blank=True, null=True)


    def __str__(self):
        return "Front Page"

    class Meta:
        verbose_name = "Front Page"



class EntryCategory(SingletonModel):
    title = models.CharField(max_length=255, blank=True, null=True)
    body = SummernoteTextField(blank=True, null=True)


    def __str__(self):
        return "Entry Category"

    class Meta:
        verbose_name = "Entry Category"


class HowTo(SingletonModel):
    title = models.CharField(max_length=255, blank=True, null=True)
    body = models.TextField(blank=True, null=True)

    def __str__(self):
        return "How To Participate"

    class Meta:
        verbose_name = "How To Participate"


class About(SingletonModel):
    title = models.CharField(max_length=255, blank=True, null=True)
    body = SummernoteTextField(blank=True, null=True)

    def __str__(self):
        return "About Text"

    class Meta:
        verbose_name = "About Text"


class Management(models.Model):
    name = models.CharField(max_length=255, default='Name')
    sub_title = models.CharField(max_length=255, default='Sub Title')
    image = models.ImageField(blank=True, null=True, upload_to="Avatar")


    def __str__(self):
        return self.name

    class Meta:
        verbose_name = "Management"



class NomineesYear(models.Model):
    models.CharField(max_length=100, blank=True, null=True)



class Nominees(models.Model):
    name = models.CharField(max_length=100, blank=True, null=True)
    year = models.ForeignKey(NomineesYear, on_delete=models.CASCADE, blank=True, null=True)
    skill =  models.CharField(max_length=100, blank=True, null=True)
    age = models.IntegerField(default=0)
    image = models.ImageField(blank=True, null=True)



class Tos(SingletonModel):
    title = models.CharField(max_length=255, blank=True, null=True)
    body = SummernoteTextField(blank=True, null=True)


    def __str__(self):
        return "Terms and Conditions"

    class Meta:
        verbose_name = "Terms and Conditions"
