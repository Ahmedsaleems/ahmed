from django.db import transaction
from django import forms
from .models import *




class ContestantForm(forms.ModelForm):
    class Meta:
        model = Contestant
        fields = ['address', 'business_venture', 'category', 'background_info','dob']

    @transaction.atomic
    def save(self, *args, **kwargs):
        contestant = super(ContestantForm, self).save(*args, **kwargs)
        if contestant.contesting == False:
            contestant.contesting = True
            contestant.save()
            return contestant

