from django.contrib import admin
from .models import *
from django_summernote.admin import SummernoteModelAdmin

# Register your models here.

class BlogAdmin(SummernoteModelAdmin):
    summernote_fields = ('body',)
    list_display = ('title', 'slug', 'date', 'image')

admin.site.register(Blog, BlogAdmin)

# class CommentAdmin(admin.ModelAdmin):
#     list_display = ('name', 'email', 'createdAt', 'publish')

# admin.site.register(Comment, CommentAdmin)

# admin.site.register(Category)

