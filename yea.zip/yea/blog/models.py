from django.db import models
from django_summernote.fields import  SummernoteTextField
from django.conf import settings
from django.urls import reverse
from autoslug import AutoSlugField



# class Category(models.Model):
#     name = models.CharField(max_length=200)

#     def __str__(self):
#         return self.name

#     def get_absolute_url(self):
#         return reverse("blog:category", kwargs={"id": self.id})



class Blog(models.Model):
    title = models.CharField(max_length=200)
    slug = AutoSlugField(populate_from='title')
    # category = models.ForeignKey(Category, on_delete=models.CASCADE)
    body = models.TextField(blank=True, null=True)
    date = models.DateField(auto_now_add=True)
    publish = models.BooleanField(default=False)
    image = models.ImageField()

    # @property
    # def get_comments():
    #     return comments.filter(publish=True)

    def __str__(self):
        return self.title

    def get_absolute_url(self):
        return reverse("blog:detail", kwargs={"slug": self.slug})

    class Meta:
        ordering = ["-date"]

# class Comment(models.Model):
#     name = models.CharField(max_length=100)
#     email = models.EmailField(null=True, blank=True)
#     body = models.TextField()
#     status = models.BooleanField(default=True)
#     post = models.ForeignKey(Blog, on_delete=models.CASCADE)
#     createdAt = models.DateTimeField(auto_now_add=True)
#     publish = models.BooleanField(default=True)

#     def __str__(self):
#         return self.name

#     class Meta:
#         ordering = ["-createdAt"]
