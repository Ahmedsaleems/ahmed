from allauth.account.views import SignupView, LoginView
from django.shortcuts import render, redirect
from subscription.models import RegistrationPayment

from vote.forms import ContestantForm
from vote.models import Slots

from .models import *
from .forms import UserForm, UserSignupForm, ProfileImageUploadForm


class UserCreateView(SignupView):
    model = CustomUser
    form_class = UserSignupForm
    template_name = 'users/register.html'
    redirect_field_name = 'next'
    view_name = 'user_sign_up'
    success_url = None

class loginView(LoginView):
    template_name = 'users/login.html'


def profileView(request):
    slots = Slots.objects.get(user=request.user)
    if request.htmx:
        image_form = ProfileImageUploadForm(request.POST, request.FILES, instance=request.user)
        if image_form.is_valid():
            image_form.save()
            return render(request, 'users/profile-img-form.html', {'image_form': image_form})
        else:
            return render(request, 'users/profile-img-form.html', {'image_form': image_form})
        
    if request.method == 'POST':
        u_form = UserForm(request.POST, request.FILES, instance=request.user)
        c_form = ContestantForm(request.POST, instance=request.user.contestant)

        if u_form.is_valid() and c_form.is_valid():
            u_form.save(commit=False)
            u_form.save()
            c_form.save()
            return redirect('frontend:home')
    else:
        image_form = ProfileImageUploadForm(instance=request.user)
        u_form = UserForm(instance=request.user)
        c_form = ContestantForm(instance=request.user.contestant)
    context = {
        'image_form': image_form,
        'u_form': u_form,
        'c_form':c_form,
        'slots':slots
     }
    return render(request, 'users/profile.html', context)


def completeRegistration(request):
    return render(request, 'users/complete-registration.html')


def complete(request):
    return render(request, 'users/complete.html')

