from django.urls import path
from .views import *

app_name = 'users'

urlpatterns = [
    path('register/', UserCreateView.as_view(), name='register'),
    path('login/', loginView.as_view(), name='login'),
    path('profile/', profileView, name='profile'),
    path('complete-registration/', completeRegistration, name="complete_registration"),
    path('complete/', complete, name="complete"),
]