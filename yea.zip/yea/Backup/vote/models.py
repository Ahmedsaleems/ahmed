from decimal import Decimal
from django.db import models
from django.conf import settings
from django.utils.translation import gettext_lazy as _
from users.models import CustomUser
from django.utils import timezone
from django.template.defaultfilters import slugify


class Country(models.Model):
    name = models.CharField(max_length=100)

    def __str__(self):
        return self.name


class Category(models.Model):
    name = models.CharField(max_length=200, blank=True, null=True)

    def __str__(self):
        return self.name


class Winners(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, null=True)
    year = models.CharField(max_length=200)
    amount_won = models.IntegerField(default=0)

    def __str__(self):
        return f'{self.user.get_full_name} - {self.year}'



class BusinessVenture(models.Model):
    name = models.CharField(max_length=100)

    def __str__(self):
        return self.name




class AwardType(models.Model):
    award_title = models.CharField(max_length=100)
    target_votes =models.IntegerField()
    price = models.DecimalField(decimal_places=2, max_digits=10)
    start_date = models.DateField(blank=True, null=True)
    end_date = models.DateField(blank=True, null=True)

    def __str__(self):
        return self.award_title



class Contestant(models.Model):
    user = models.OneToOneField(CustomUser, on_delete=models.CASCADE)
    dob = models.DateField('Date of Birth', blank=True, null=True)
    address = models.CharField(max_length=250, blank=True, null=True)
    slug = models.SlugField(unique=True, null=True, blank=True)
    vote_count = models.IntegerField(default=0, editable=True)
    voters = models.ManyToManyField(CustomUser, related_name='votes', blank=True)
    business_venture = models.ForeignKey(BusinessVenture, on_delete=models.CASCADE, blank=True, null=True)
    category = models.ForeignKey(Category, on_delete=models.CASCADE, blank=True, null=True)
    background_info = models.TextField(blank=True, null=True)
    contesting = models.BooleanField(default=False)
    dropped = models.BooleanField(default=False)
    createdAt = models.DateTimeField(auto_now_add=True)
    
    
    
    def save(self, *args, **kwargs):
        if not self.slug:
            new_slug = slugify(self.user.get_full_name) + "-" + str(self.user.id)
            self.slug = new_slug
        
        super().save(*args, **kwargs)


    def __str__(self):
        return f'{self.user.first_name} {self.user.last_name}'

    @property
    def get_dob(self):
        if self.dob:
            age = timezone.localdate() - self.dob
            return round(age.days/360)




class Slots(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, null=True)
    vote_slots = models.IntegerField(default=0, editable=True)
    createdAt = models.DateTimeField(auto_now_add=True)

    # def __str__(self):
    #     return f"{self.user.get_full_name} - {self.slots}"



class ContestSettings(models.Model):
    title = models.CharField(max_length=50, blank=True, null=True)
    start_date = models.DateField(blank=True, null=True)
    end_date = models.DateField(blank=True, null=True)
    
 
    def __str__(self):
        return self.title




class WeekTable(models.Model):
    title = models.CharField(max_length=100, blank=True, null=True)
    award_type = models.ForeignKey(AwardType, on_delete=models.CASCADE, blank=True, null=True)
    week_number = models.CharField(max_length=100, blank=True, null=True)
    target = models.IntegerField(default=0)
    start_date = models.DateField(blank=True, null=True)
    end_date = models.DateField(blank=True, null=True)
    
 
    def __str__(self):
        return self.title


class LevelsControl(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, null=True)
    week_table = models.ForeignKey(WeekTable, on_delete=models.CASCADE, blank=True, null=True)




     



