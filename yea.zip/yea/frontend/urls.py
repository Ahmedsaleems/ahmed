from django.urls import path
from .views import *

app_name = 'frontend'

urlpatterns = [
    path('', home, name='home'),
    path('entry-categories/', entyCategoryView, name='entry'),
    path('how-to-participate/', HowToView, name='how'),
    path('about-yea/', AboutView, name='about'),
    path('contact/', ContactView, name='contact'),
    path('Terms-and-conditions/', TosView, name='tos'),






    
]