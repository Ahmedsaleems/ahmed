from time import timezone
import json
from django.shortcuts import render, redirect
from subscription.models import RegistrationPayment, Transaction
from users.decorators import contestant_required
from users.forms import *
from .forms import *
from django.contrib.auth.decorators import login_required
from django.http import HttpResponse
import sweetify
from django.contrib import messages
from django.http import  HttpResponse, HttpResponseRedirect
from utils.utils import Flutterwave
from vote.models import Slots
from uuid import uuid4

flutterwave = Flutterwave()



@login_required
def contestView(request):
    payment = RegistrationPayment.objects.get(user=request.user)
    if request.method == 'POST':
        u_form = UserForm(request.POST, request.FILES, instance=request.user)
        c_form = ContestantForm(request.POST, instance=request.user.contestant)
        print("c_form", c_form)

        if u_form.is_valid() and c_form.is_valid():
            u_form.save(commit=False)
            request.user.is_contestant = True
            request.user.is_subscriber = False
            # if payment.amount == 2:
            #     payment.amount -= 2
            #     payment.save()
            u_form.save()
            c_form.save()

            return redirect('vote:vote_now')
    else:
        u_form = UserForm(instance=request.user)
        c_form = ContestantForm(instance=request.user.contestant)

    context = {
        'u_form': u_form,
        'c_form':c_form,
     }

    return render(request, 'vote/contest.html', context)


def voteNow(request):    
    contestants = Contestant.objects.filter(contesting=True, dropped=False)
    contestant = Contestant.objects.get(id=9)
    categories = Category.objects.all()
    colorCodes = AwardType.objects.all()
    for color in colorCodes:
        if color.award_title == "National Award":
            redColor = color.get_redColor
            print("Red", redColor)
            yellowColor = color.get_yellowColor
            print("Yellow", yellowColor)
            greenColor = color.get_greenColor
            print("Green", greenColor)




    context = {
        'contestants':contestants,
        'categories': categories,
        'redColor': redColor,
        'yellowColor':yellowColor,
        'greenColor':greenColor,
    #    # 'slot': slot,
    }

    if request.htmx:
        if 'category' in request.GET:
            category = request.GET.get('category', '')
            if category:
                contestants = Contestant.objects.filter(contesting=True, category__name=category, dropped=False)
            else:
                contestants = Contestant.objects.filter(contesting=True, dropped=False)
            context = {
                'contestants': contestants
            }
            return render(request, 'partials/voteCard.html', context)
        else:
            return render(request, 'partials/voteCard.html', context)

    return render(request, 'vote/vote_now.html', context)


def votePost(request):
    if not request.user.is_authenticated:
        if request.htmx:
            return render(request, 'partials/message_to_login.html', {})
    payment_flag = RegistrationPayment.objects.get(user=request.user)
    slot = Slots.objects.get(user=request.user)
    contestants = Contestant.objects.filter(contesting=True, dropped=False)


    if request.method == 'POST':
        contestant = Contestant.objects.get(pk=request.POST.get('cont_id'))
        if payment_flag.amount == 2:
            contestant.vote_count += 1
            contestant.voters.add(request.user)
            contestant.save()
            payment_flag.amount -= 2
            payment_flag.save()
            messages.info(request, 'You have voted successfully')

        elif  slot.vote_slots > 0:
            contestant.vote_count += 1
            contestant.voters.add(request.user)
            contestant.save()
            slot.vote_slots -= 1
            slot.save()
            messages.info(request, 'You have voted successfully')
        else:
            messages.error(request, 'Not enough credit to vote. ')

        context = {
            'slot': slot,
            'contestants': contestants
        }

        if request.htmx:
            return render(request, 'partials/voteCard.html', context)







@login_required
def recharge(request):
    if request.method == 'POST':
        amount = request.POST.get('amount')
        reference = str(uuid4().int >> 100)
        params = {
                'tx_ref': reference,
                'amount': str(amount),
                'currency': 'USD',
                "payment_options":"card",
                'customer': { 'email': request.user.email },
                'redirect_url': settings.FLUTTERWAVE_CALLBACK_URL2,
            }
        print("params",  params)
        response = flutterwave.post('payments', params=json.dumps(params)).json()
        print('Flutterwave: ', response)
        if response['status'] == 'success':
            pass
            return HttpResponseRedirect(response['data']['link'])

    return render(request, 'vote/buy_votes.html')


@login_required
def verify_payment(request):
    user = CustomUser.objects.get(email=request.user.email)
    print("user", user)
    if request.method == 'GET':
        if 'tx_ref' in request.GET:
            tx_ref = request.GET['tx_ref']
            transaction_id = request.GET['transaction_id']
            response = flutterwave.get('transactions/{}/verify'.format(transaction_id)).json()
            if response['status'] == 'success':
                transaction = response['data']
                print("Transactions", transaction)
                if transaction['status'] == 'successful':
                    tran, created = Transaction.objects.get_or_create(
                        transaction_id=transaction['id'], data=transaction,  payment_gateway='Flutterwave', user=CustomUser.objects.get(email=transaction['customer']['email']))
                    tran.data = transaction
                    user_slot = Slots.objects.get(user=request.user)
                    if user_slot:
                        user_slot.vote_slots += transaction['amount']
                        user_slot.save()
               
                return redirect('vote:vote_now')
    return HttpResponse('Payment unsuccessful.')


def share_page(request, slug):
    contestant = Contestant.objects.get(slug=slug, user=request.user)
    slot = Slots.objects.get(user=request.user)
    payment_flag = RegistrationPayment.objects.get(user=request.user)

    if request.method == 'POST':
        contestant = contestant
        if payment_flag.amount == 2:
            contestant.vote_count += 1
            contestant.voters.add(request.user)
            contestant.save()
            payment_flag.amount -= 2
            payment_flag.save()
            messages.info(request, 'You have voted successfully')

        elif  slot.vote_slots > 0:
            contestant.vote_count += 1
            contestant.voters.add(request.user)
            contestant.save()
            slot.vote_slots -= 1
            slot.save()
            messages.success(request, 'You have voted successfully')
        else:
            messages.error(request, 'Not enough credit to vote. ')

        # return redirect('vote:share' )
    context = {
        'contestant': contestant
    }

    if request.htmx:
        context = {
            'contestant': contestant
        }
        return render(request, 'partials/shareButton.html', context)
    return render(request, 'vote/share.html', context)
