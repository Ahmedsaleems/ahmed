import json
from uuid import uuid4
from dateutil.relativedelta import relativedelta
from datetime import datetime
from django.shortcuts import redirect, render
from django.conf import settings
from django.http import  HttpResponse, HttpResponseRedirect
from django.template.loader import render_to_string
from django.core.mail import EmailMessage
from django.contrib.auth.decorators import login_required

from utils.utils import Flutterwave
from vote.models import Slots
from .models import *
# import sweetify


flutterwave = Flutterwave()

@login_required
def subscribe(request):
    if request.method == 'POST':
        paymentsettings = PaymentSettings.objects.get()
        reference = str(uuid4().int >> 100)
        params = {
                'tx_ref': reference,
                'amount': str(paymentsettings.registration_fee),
                'currency': paymentsettings.currency,
                "payment_options":"card",
                'customer': {
                    'email': request.user.email
                },
                'redirect_url': settings.FLUTTERWAVE_CALLBACK_URL,
            }
        print("params",  params)
        response = flutterwave.post('payments', params=json.dumps(params)).json()
        print('Flutterwave: ', response)
        if response['status'] == 'success':
            pass
            return HttpResponseRedirect(response['data']['link'])

        return HttpResponse('Subscription Failed.')


@login_required
def verify_payment(request):
    paymentsettings = PaymentSettings.objects.get()
    user = CustomUser.objects.get(email=request.user.email)
    if request.method == 'GET':
        if 'tx_ref' in request.GET:
            tx_ref = request.GET['tx_ref']
            transaction_id = request.GET['transaction_id']
            response = flutterwave.get('transactions/{}/verify'.format(transaction_id)).json()

            if response['status'] == 'success':
                transaction = response['data']
                if transaction['status'] == 'successful':
                    tran, created = Transaction.objects.get_or_create(
                        transaction_id=transaction['id'],  payment_gateway='Flutterwave', user=CustomUser.objects.get(email=transaction['customer']['email']))
                    tran.data = transaction
                    if user.is_paid == False:
                        payment, created = RegistrationPayment.objects.get_or_create(
                            payment_id=transaction['id'], 
                            # payment_option=transaction['payment_type'],
                            user=CustomUser.objects.get(email=transaction['customer']['email']),
                            amount=transaction['amount'],
                            currency=paymentsettings.currency,
                            payment_date=transaction['created_at'],
                            )
                        payment.save()
                        user.is_paid = True
                        user.is_subscriber = True
                        user.save()

              
        return redirect('users:complete')
    return HttpResponse('Payment failed.')

