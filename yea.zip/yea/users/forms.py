from dataclasses import fields
from email.policy import default
from django.db import transaction
from django import forms
from allauth.account.forms import SignupForm
from django.contrib.auth import get_user_model


from .models import Country, CustomUser


User = get_user_model()


class UserSignupForm(SignupForm):
    first_name = forms.CharField(required=True)
    last_name = forms.CharField(required=True)
    email = forms.EmailField(required=True)
    phone = forms.CharField(required=True)
    tos = forms.BooleanField(initial=False)
    country = forms.ModelChoiceField(queryset=Country.objects.all())



    @transaction.atomic
    def save(self, request):
        user = super(UserSignupForm, self).save(request)
        user.first_name = self.cleaned_data.get('first_name')
        user.last_name = self.cleaned_data.get('last_name')
        user.email = self.cleaned_data.get('email')
        user.tos = self.cleaned_data.get('tos')
        user.phone = self.cleaned_data.get('phone')
        user.country = self.cleaned_data.get('country')

        user.save()
        # LawyerProfile.objects.get_or_create(user=user)
        return user


class UserForm(forms.ModelForm):
    class Meta:
        model = CustomUser
        fields = ('country','first_name', 'last_name', 'phone', 'email', 'avatar', 'tos')



class ProfileImageUploadForm(forms.ModelForm):
    class Meta:
        model = CustomUser
        fields = ('avatar',)

