# from blog.forms import CommentForm
from django.shortcuts import render, redirect, get_object_or_404, HttpResponseRedirect


from blog.models import Blog

# Create your views here.

def blog(request):
    blogs = Blog.objects.filter(publish=True)

    context = {"blogs":blogs}
    return render(request, 'blog/blog.html', context)

def blogDetail(request, slug):
    latest_post = Blog.objects.exclude(slug=slug)
    # category = Category.objects.all()[:10]
    blog = Blog.objects.get(slug=slug)
    # if request.method == "POST":
    #     form = CommentForm(request.POST)
    #     if form.is_valid():
    #         newform = form.save(commit=False)
    #         newform.post = blog
    #         # newform.user = request.user
    #         newform.save()
    #         return HttpResponseRedirect('/blog/blog/' + str(blog.slug))
    # else:
    #     form = CommentForm()
    context = {
        "blog":blog, 
        # 'form': form, 
        'latest_post':latest_post,
        # "category":category
        }

    # if request.htmx:
    #     return render(request, 'partials/comment.html', context)

    return render(request, 'blog/blog-details.html', context)


# def categoryList(request, id):
#     category = Category.objects.get(id=id)
#     blogs = Blog.objects.filter(category=category)


#     context = {
#         "category":category,
#         "blogs":blogs
#     }

#     return render(request, 'blog/category-list.html', context)