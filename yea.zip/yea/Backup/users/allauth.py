import threading

from django.urls import reverse
from django.contrib.sites.shortcuts import get_current_site

from allauth.account.adapter import DefaultAccountAdapter, get_adapter


class MyAccountAdapter(DefaultAccountAdapter):

    def send_mail(self, template_prefix, email, context):
        mailing_thread = threading.Thread(
            target=super(MyAccountAdapter, self).send_mail,
            args=(template_prefix, email, context)
        )
        mailing_thread.start()

    def get_login_redirect_url(self, request):
        if request.user.is_paid == False:
            return reverse('users:complete_registration')
        elif  request.user.is_paid:
            return reverse('vote:vote_now')
        else:
            return reverse('frontend:home')
        # elif  request.user.is_lawfirm:
        #     return reverse('dashboard:lawfirm_profile')
        # elif request.user.is_subscriber:
        #     return reverse('users:lawyer_search')
        # elif request.user.is_admin or request.user.is_editor:
        #     return reverse('admindashboard:home')
        # elif request.user.is_superuser:
        #     return reverse('admindashboard:home')
        # else:
        #     return reverse('frontend:home')

    # def send_confirmation_mail(self, request, emailconfirmation, signup):
    #     current_site = get_current_site(request)
    #     activate_url = self.get_email_confirmation_url(request, emailconfirmation)
    #     ctx = {
    #         "user": emailconfirmation.email_address.user,
    #         "activate_url": activate_url,
    #         "current_site": current_site,
    #         "key": emailconfirmation.key,
    #         "otp": emailconfirmation.email_address.user.otp,
    #     }
        
    #     if signup:
    #         if self.is_ajax(request):
    #             email_template = "account/email/email_confirmation_signup_otp"
    #         else:
    #             email_template = "account/email/email_confirmation_signup"
    #     else:
    #         if self.is_ajax(request):
    #             email_template = "account/email/email_confirmation_otp"
    #         else:
    #             email_template = "account/email/email_confirmation"
    #     self.send_mail(email_template, emailconfirmation.email_address.email, ctx)
