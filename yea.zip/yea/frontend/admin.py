from django.contrib import admin
from solo.admin import SingletonModelAdmin
from .models import *
from django_summernote.admin import SummernoteModelAdmin


class HowToAdmin(SummernoteModelAdmin):
    summernote_fields = ('body',)

admin.site.register(FrontPage, SingletonModelAdmin)
admin.site.register(Management)
admin.site.register(EntryCategory)
admin.site.register(HowTo, HowToAdmin)
admin.site.register(About)
admin.site.register(NomineesYear)
admin.site.register(Tos)






class NomineesAdmin(admin.ModelAdmin):
    list_display = ('name', 'age', 'skill', 'year', 'image')

admin.site.register(Nominees, NomineesAdmin)



