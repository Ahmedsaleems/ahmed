from django.contrib import admin
from .models import*
from import_export.admin import ImportExportModelAdmin
from solo.admin import SingletonModelAdmin
# Register your models here.


class TransactionAdmin(admin.ModelAdmin):
    list_display = ('transaction_id', 'payment_gateway', 'data', 'user', 'transaction_date')

admin.site.register(Transaction, TransactionAdmin)


class RegistrationPaymentAdmin(admin.ModelAdmin):
    list_display = ('payment_id', 'user', 'amount', 'payment_date', )

admin.site.register(RegistrationPayment, RegistrationPaymentAdmin)




admin.site.register(PaymentSettings, SingletonModelAdmin)
